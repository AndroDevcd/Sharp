cmake_minimum_required(VERSION 3.6)
project(Sharp)

set(CMAKE_C_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# Detect OS (matching build.sh logic)
if(CMAKE_SYSTEM_NAME STREQUAL "Darwin")
    # macOS-specific flags (no -lrt and no --no-as-needed)
    set(CXX_COMPILER "g++-15")
    set(PLATFORM_FLAGS "")
    set(STDLIB_FLAG "")
    set(REDZONE_FLAG "")
else()
    # Default flags (Linux/other)
    set(CXX_COMPILER "g++")
    set(PLATFORM_FLAGS "-Wl,--no-as-needed -lrt -mno-red-zone -fsanitize=address")
    set(STDLIB_FLAG "-lstdc++")
    set(REDZONE_FLAG "-mno-red-zone")
    set(CMAKE_EXE_LINKER_FLAGS ${CMAKE_EXE_LINKER_FLAGS} "-static")
endif()

set(BUILD_SHARED_LIBS OFF)

# Set compiler flags using platform-specific variables
set(CMAKE_CXX_FLAGS_DEBUG  "-fno-omit-frame-pointer -DASMJIT_STATIC ${REDZONE_FLAG} -std=c++17 -O0 -pthread ${STDLIB_FLAG} -g -gdwarf-4 ${CMAKE_CXX_FLAGS_DEBUG}")
set(CMAKE_CXX_FLAGS_MINSIZEREL  "-Werror ${STDLIB_FLAG} ${REDZONE_FLAG} -s -O3 -Ofast ${CMAKE_CXX_FLAGS_MINSIZEREL}")
set(CMAKE_CXX_FLAGS_RELWITHDEBINFO   "-fsanitize=address ${REDZONE_FLAG} -pthread ${STDLIB_FLAG} -O3 -Ofast ${CMAKE_CXX_FLAGS_RELWITHDEBINFO}")
set(CMAKE_CXX_FLAGS_RELEASE   "${REDZONE_FLAG} -pthread ${STDLIB_FLAG} -O3 -Ofast ${CMAKE_CXX_FLAGS_RELEASE}")

# For runtime builds, also set DASMJIT_STATIC flag
#set(CMAKE_RUNTIME_CXX_FLAGS_DEBUG  "-std=c++17 -g ${STDLIB_FLAG} -DASMJIT_STATIC ${PLATFORM_FLAGS} ${CMAKE_C_FLAGS_DEBUG}")
#set(CMAKE_RUNTIME_CXX_FLAGS_RELEASE   "-std=c++17 ${REDZONE_FLAG} -Werror ${STDLIB_FLAG} -DASMJIT_STATIC ${PLATFORM_FLAGS} -O3 -g ${CMAKE_C_FLAGS_RELEASE}")

#set(SHARPC "build")
#set(LEGACY "build")

# compiler
if (SHARPC)
    add_definitions(-DMAKE_COMPILER)

    file(GLOB compiler_SRC
            "lib/grammar/*.h"
            "lib/grammar/*.cpp"
            "lib/grammar/json/*.h"
            "lib/grammar/json/*.cpp"
            "lib/grammar/settings/*.h"
            "lib/grammar/settings/*.cpp"
            "lib/grammar/frontend/tokenizer/*.h"
            "lib/grammar/frontend/tokenizer/*.cpp"
            "lib/grammar/frontend/parser/*.h"
            "lib/grammar/frontend/parser/*.cpp"
            "lib/grammar/frontend/*.h"
            "lib/grammar/frontend/*.cpp"
            "lib/grammar/taskdelegator/*.h"
            "lib/grammar/taskdelegator/*.cpp"
            "lib/grammar/backend/dependency/*.h"
            "lib/grammar/backend/dependency/*.cpp"
            "lib/grammar/backend/preprocessor/*.h"
            "lib/grammar/backend/preprocessor/*.cpp"
            "lib/grammar/backend/postprocessor/*.h"
            "lib/grammar/backend/postprocessor/*.cpp"
            "lib/grammar/backend/astparser/*.h"
            "lib/grammar/backend/astparser/*.cpp"
            "lib/grammar/backend/context/*.h"
            "lib/grammar/backend/context/*.cpp"
            "lib/grammar/backend/compiler/*.h"
            "lib/grammar/backend/compiler/*.cpp"
            "lib/grammar/backend/compiler/expressions/*.h"
            "lib/grammar/backend/compiler/expressions/*.cpp"
            "lib/grammar/backend/compiler/expressions/binary/*.h"
            "lib/grammar/backend/compiler/expressions/binary/*.cpp"
            "lib/grammar/backend/compiler/expressions/primary/*.h"
            "lib/grammar/backend/compiler/expressions/primary/*.cpp"
            "lib/grammar/backend/compiler/expressions/unary/*.h"
            "lib/grammar/backend/compiler/expressions/unary/*.cpp"
            "lib/grammar/backend/operation/*.h"
            "lib/grammar/backend/operation/*.cpp"
            "lib/grammar/backend/*.h"
            "lib/grammar/backend/*.cpp"
            "lib/grammar/backend/types/*.h"
            "lib/grammar/backend/types/*.cpp"
            "lib/grammar/backend/compiler/di/*.h"
            "lib/grammar/backend/compiler/di/*.cpp"
            "lib/grammar/backend/compiler/functions/*.h"
            "lib/grammar/backend/compiler/functions/*.cpp"
            "lib/grammar/backend/compiler/functions/statements/*.h"
            "lib/grammar/backend/compiler/functions/statements/*.cpp"
            "lib/grammar/backend/finalizer/*.h"
            "lib/grammar/backend/finalizer/*.cpp"
            "lib/grammar/backend/finalizer/optimization/*.h"
            "lib/grammar/backend/finalizer/optimization/*.cpp"
            "lib/grammar/backend/optimizer/*.h"
            "lib/grammar/backend/optimizer/*.cpp"
            "lib/grammar/backend/optimizer/passes/*.h"
            "lib/grammar/backend/optimizer/passes/*.cpp"
            "lib/grammar/backend/optimizer/analysis/*.h"
            "lib/grammar/backend/optimizer/analysis/*.cpp"
            "lib/grammar/backend/finalizer/optimization/analyzer/*.h"
            "lib/grammar/backend/finalizer/optimization/analyzer/*.cpp"
            "lib/grammar/backend/finalizer/optimization/processor/*.h"
            "lib/grammar/backend/finalizer/optimization/processor/*.cpp"
            "lib/grammar/backend/finalizer/generation/*.h"
            "lib/grammar/backend/finalizer/generation/*.cpp"
            "lib/grammar/backend/finalizer/generation/code/*.h"
            "lib/grammar/backend/finalizer/generation/code/*.cpp"
            "lib/grammar/backend/finalizer/generation/obfuscation/*.h"
            "lib/grammar/backend/finalizer/generation/obfuscation/*.cpp"
            "lib/grammar/backend/finalizer/generation/code/scheme/*.h"
            "lib/grammar/backend/finalizer/generation/code/scheme/*.cpp"
            "lib/util/*.cpp"
            "lib/util/zip/*.cpp"
            "lib/core/*.cpp"
            "lib/core/*.h"
            "lib/core/opcode/*.cpp"
            "lib/core/opcode/*.h"
    )



    set(SOURCE_FILES main.cpp stdimports.h ${compiler_SRC})

    add_executable(Sharpc ${SOURCE_FILES})
    
    # Link libraries based on platform
    if(CMAKE_SYSTEM_NAME STREQUAL "Darwin")
        target_link_libraries(Sharpc stdc++)
    else()
        target_link_libraries(Sharpc stdc++ rt)
    endif()
elseif(LEGACY)
    add_definitions(-DMAKE_COMPILER)

    file(GLOB compiler_SRC
            "lib/old_grammar/*.h"
            "lib/old_grammar/*.cpp"
            "lib/old_grammar/optimizer/*.h"
            "lib/old_grammar/optimizer/*.cpp"
            "lib/old_grammar/generator/*.h"
            "lib/old_grammar/generator/*.cpp"
            "lib/old_grammar/frontend/tokenizer/*.h"
            "lib/old_grammar/frontend/tokenizer/*.cpp"
            "lib/old_grammar/frontend/parser/*.h"
            "lib/old_grammar/frontend/parser/*.cpp"
            "lib/old_grammar/frontend/*.h"
            "lib/old_grammar/frontend/*.cpp"
            "lib/old_grammar/backend/*.h"
            "lib/old_grammar/backend/*.cpp"
            "lib/old_grammar/backend/oo/*.h"
            "lib/old_grammar/backend/oo/*.cpp"
            "lib/old_grammar/backend/ofuscation/*.h"
            "lib/old_grammar/backend/ofuscation/*.cpp"
            "lib/old_grammar/backend/data/*.h"
            "lib/old_grammar/backend/data/*.cpp"
            "lib/old_grammar/backend/code/*.h"
            "lib/util/*.cpp"
            "lib/util/*.h"
            "lib/util/zip/*.cpp"
            "lib/util/zip/*.h"
            "lib/core/*.cpp"
            "lib/core/*.h"
            "lib/core/opcode/*.cpp"
            "lib/core/opcode/*.h"
            )


    set(SOURCE_FILES main.cpp stdimports.h ${compiler_SRC})

    add_executable(LegacySharpc ${SOURCE_FILES})
else()
    #virtual machine
    add_definitions(-DDEBUGGING)

    file(GLOB runtime_SRC
            "lib/runtime/error/*.h"
            "lib/runtime/error/*.cpp"
            "lib/runtime/exe/*.h"
            "lib/runtime/exe/*.cpp"
            "lib/runtime/memory/*.h"
            "lib/runtime/memory/*.cpp"
            "lib/runtime/reflect/*.h"
            "lib/runtime/reflect/*.cpp"
            "lib/runtime/jit/*.h"
            "lib/runtime/jit/*.cpp"
            "lib/runtime/jit/arm/*.h"
            "lib/runtime/jit/arm/*.cpp"
            "lib/runtime/jit/arm/opcode/*.h"
            "lib/runtime/jit/arm/opcode/*.cpp"
            "lib/runtime/jit/arm/sections/*.h"
            "lib/runtime/jit/arm/sections/*.cpp"
            "lib/runtime/jit/x64/*.h"
            "lib/runtime/jit/x64/*.cpp"
            "lib/runtime/jit/x64/opcode/*.cpp"
            "lib/runtime/jit/x64/sections/*.cpp"
            "lib/runtime/telemetry/*.h"
            "lib/runtime/telemetry/*.cpp"
            "lib/runtime/snb/*.h"
            "lib/runtime/snb/*.cpp"
            "lib/runtime/multitasking/*/*.h"
            "lib/runtime/multitasking/*/*.cpp"
            "lib/runtime/types/*.h"
            "lib/runtime/types/*.cpp"
            "lib/runtime/*.h"
            "lib/runtime/*.cpp"
            "lib/core/*.cpp"
            "lib/core/*.h"
            "lib/core/opcode/*.cpp"
            "lib/core/opcode/*.h"
            "lib/util/*.cpp"
            "lib/util/*.h"
            "lib/util/jit/asmjit/src/asmjit/*.cpp"
            "lib/util/jit/asmjit/src/asmjit/*.h"
            "lib/util/jit/asmjit/src/asmjit/arm/*.cpp"
            "lib/util/jit/asmjit/src/asmjit/arm/*.h"
            "lib/util/jit/asmjit/src/asmjit/core/*.cpp"
            "lib/util/jit/asmjit/src/asmjit/core/*.h"
            "lib/util/jit/asmjit/src/asmjit/x86/*.cpp"
            "lib/util/jit/asmjit/src/asmjit/x86/*.h"
            "lib/util/zip/*.cpp"
            "lib/util/zip/*.h"
            "lib/Modules/math/*.h"
            "lib/Modules/math/*.cpp"
            "lib/Modules/std/*.h"
            "lib/Modules/std/*.cpp"
            "lib/Modules/std.io/*.h"
            "lib/Modules/std.io/*.cpp"
            )

    set(SOURCE_FILES main.cpp stdimports.h ${runtime_SRC}
            lib/runtime/reflect/reflection.cpp
            lib/runtime/reflect/reflection.h)
    add_executable(Sharp ${SOURCE_FILES})

    # Link libraries based on platform  
    if(CMAKE_SYSTEM_NAME STREQUAL "Darwin")
        target_link_libraries(Sharp stdc++ m dl)
    else()
        target_link_libraries(Sharp stdc++ rt m dl)
    endif()
endif ()
