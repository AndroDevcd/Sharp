//
// Created by BNunnally on 9/9/2021.
//

#include "context.h"
#include "../../../core/access_flag.h"
#include "../types/sharp_class.h"
#include "../../sharp_file.h"
#include "../../taskdelegator/task_delegator.h"
#include "../types/types.h"
#include "../../compiler_info.h"
#include "../operation/operation.h"

void create_context(sharp_class *sc, bool isStatic) {
    create_context(&currThread->currTask->file->ctx, sc, isStatic);
}

void create_context(sharp_field *sf) {
    create_context(&currThread->currTask->file->ctx, sf, check_flag(sf->flags, flag_static));
}

void create_context(sharp_function *fun) {
    create_context(&currThread->currTask->file->ctx, fun, check_flag(fun->flags, flag_static));
}

void create_context(component *comp) {
    create_context(&currThread->currTask->file->ctx, comp);
}

void create_context(context *ctx, sharp_class *sc, bool isStatic) {
    if(ctx->type != no_context) {
        store_context(ctx);
    }

    if(check_flag(sc->flags, flag_global))
        ctx->type = global_context;
    else ctx->type = class_context;

    ctx->classCxt = sc;
    ctx->isStatic = isStatic;
}

void create_context(context *ctx, sharp_field *sf, bool isStatic) {
    if(ctx->type != no_context) {
        store_context(ctx);
    }

    ctx->type = field_context;
    ctx->fieldCxt = sf;
    ctx->isStatic = isStatic;
}

void create_context(context *ctx, sharp_function *fun, bool isStatic) {
    if(ctx->type != no_context) {
        store_context(ctx);
    }

    ctx->type = block_context;
    ctx->functionCxt = fun;
    ctx->isStatic = isStatic;
    ctx->localFields.addAll(fun->parameters);
    ctx->blockInfo.free();
}

void create_block(context *ctx, block_type type) {
    if(ctx->blockInfo.type != invalid_block) {
        store_block(&ctx->blockInfo);
    }

    ctx->blockInfo.type = type;
    if(ctx->blockInfo.storedItems.empty())
        ctx->blockInfo.id = 0;
    else ctx->blockInfo.id = ctx->blockInfo.storedItems.last()->id + 1;
}

void create_context(context *ctx, component *comp) {
    if(ctx->type != no_context) {
        store_context(ctx);
    }

    ctx->type = component_context;
    ctx->componentCtx = comp;
}

void delete_block() {
    delete_block(&currThread->currTask->file->ctx.blockInfo);
}

void delete_context() {
    delete_context(&currThread->currTask->file->ctx);
}

void delete_block(block_info *info) {
    for(Int i = current_context.functionCxt->parameters.size(); i < current_context.localFields.size(); i++) {
        sharp_field *field = current_context.localFields.get(i);

        if(field->block == info->id) {
            current_context.localFields.remove(field);
            i--;
        }
    }

    if(info->storedItems.empty()) {
        info->type = invalid_block;
        info->id = -1;
        info->line = -1;
        info->reachable = true;
        info->lockExpression = NULL;
        deleteList(info->storedItems);
    } else {
        restore_block(info);
    }
}

void delete_context(context *ctx) {
    if(ctx->storedItems.empty()) {
        ctx->type = no_context;
        ctx->functionCxt = NULL;
        ctx->componentCtx = NULL;
        ctx->classCxt = NULL;
        ctx->isStatic = false;
        ctx->localFields.free();
        deleteList(ctx->blockInfo.storedItems);
    } else {
        restore_context(ctx);
    }
}

void store_block(block_info *info) {
    info->storedItems.add(new stored_block_info(*info));
}

isolated_context_scope::isolated_context_scope(context *ctx)
        : ctx(ctx) {
    memcpy(saved, (void*)ctx, sizeof(context));
    new (ctx) context();
}

isolated_context_scope::~isolated_context_scope() {
    ctx->~context();
    memcpy((void*)ctx, saved, sizeof(context));
}

void store_context(context *ctx) {
    ctx->storedItems.add(new stored_context_item(*ctx));
}

void retrieve_lock_expressions(block_info *info, List<Ast*> &expressions) {
    if(info->lockExpression != NULL)
        expressions.add(info->lockExpression);

    for(Int i = 0; i < info->storedItems.size(); i++) {
        if(info->storedItems.get(i)->lockExpression != NULL)
            expressions.add(info->storedItems.get(i)->lockExpression);
    }
}

bool inside_block(block_info *info, block_type type) {
    if(info->type != type) {
        for(Int i = 0; i < info->storedItems.size(); i++) {
            if(info->storedItems.get(i)->type == type)
                return true;
        }

        return false;
    } else return true;
}

/** how many blocks of `type` the code being compiled is inside of (0 = none) */
Int enclosing_blocks(block_info *info, block_type type) {
    Int count = info->type == type ? 1 : 0;
    for(Int i = 0; i < info->storedItems.size(); i++) {
        if(info->storedItems.get(i)->type == type)
            count++;
    }
    return count;
}

stored_block_info* retrieve_block(block_info *info, block_type type) {
    if(info->type != type) {
        for(Int i = (Int)info->storedItems.size() - 1; i >= 0; i--) {
            if(info->storedItems.get(i)->type == type)
                return info->storedItems.get(i);
        }

        return NULL;
    } else return info;
}

sharp_label* retrieve_next_finally_label(block_info *info) {
    if(info->finallyLabel != NULL)
        return info->finallyLabel;

    for(Int i = (Int)info->storedItems.size() - 1; i >= 0; i--) {
        if(info->storedItems.get(i)->finallyLabel != NULL)
            return info->storedItems.get(i)->finallyLabel;
    }
    return NULL;
}

static bool is_loop_block(block_type type) {
    return type == for_block || type == for_each_block
        || type == while_block || type == do_while_block;
}

// Collects the finally blocks a jump has to run on its way out, innermost first.
// stopAtLoop: used by break/continue, which only leave the nearest enclosing loop and
// therefore must not run the finally block of a try that encloses that loop.
void retrieve_finally_labels(block_info *info, List<sharp_label*> &labels, bool stopAtLoop) {
    // (a block opened with create_block() alone inherits the label of the block around it,
    //  so the same label can show up on consecutive levels: only take it once)
    if(info->finallyLabel != NULL)
        labels.add(info->finallyLabel);
    if(stopAtLoop && is_loop_block(info->type))
        return;

    for(Int i = (Int)info->storedItems.size() - 1; i >= 0; i--) {
        sharp_label *label = info->storedItems.get(i)->finallyLabel;
        if(label != NULL && (labels.empty() || labels.last() != label))
            labels.add(label);
        if(stopAtLoop && is_loop_block(info->storedItems.get(i)->type))
            return;
    }
}

void restore_block(block_info *info) {
    // we preserve any carry-over items from the block were exiting
    info->copy(*info->storedItems.last());
    info->reachable = info->storedItems.last()->reachable;

    free(info->storedItems.last());
    info->storedItems.pop_back();
}

void restore_context(context *ctx) {
    stored_context_item item(*ctx->storedItems.last());
    delete ctx->storedItems.last();     // made with `new` in store_context()
    ctx->storedItems.pop_back();
    ctx->copy(item);
}

sharp_class *get_primary_class(context *ctx) {
    if(ctx->type == class_context || ctx->type == global_context)
        return ctx->classCxt;

    for(Int i = (Int)ctx->storedItems.size() - 1; i >= 0; i--) {
        stored_context_item *contextItem = ctx->storedItems.get(i);
        if(contextItem->type == class_context
            || contextItem->type == global_context)
            return contextItem->classCxt;
    }

    return NULL;
}

component *get_primary_component(context *ctx) {
    if(ctx->type == component_context)
        return ctx->componentCtx;

    for(Int i = (Int)ctx->storedItems.size() - 1; i >= 0; i--) {
        stored_context_item *contextItem = ctx->storedItems.get(i);
        if(contextItem->type == component_context
            || contextItem->type == global_context)
            return contextItem->componentCtx;
    }

    return NULL;
}

sharp_field *get_primary_field(context *ctx) {
    if(ctx->type == field_context)
        return ctx->fieldCxt;

    sharp_field *sf = NULL;
    for(Int i = (Int)ctx->storedItems.size() - 1; i >= 0; i--) {
        stored_context_item *contextItem = ctx->storedItems.get(i);
        if(contextItem->type == field_context)
            sf = contextItem->fieldCxt;
    }

    return sf;
}

sharp_function *get_primary_function(context *ctx) {
    if(ctx->type == block_context)
        return ctx->functionCxt;

    sharp_function *fun = NULL;
    for(Int i = (Int)ctx->storedItems.size() - 1; i >= 0; i--) {
        stored_context_item *contextItem = ctx->storedItems.get(i);
        if(contextItem->type == block_context)
            fun = contextItem->functionCxt;
    }

    return fun;
}

void block_info::copy_all(const block_info &info)  {
    copy(*this);
    deleteList(storedItems);

    for(Int i = 0; i < info.storedItems.size(); i++) {
        storedItems.add(new stored_block_info(*info.storedItems.get(i)));
    }
}

void stored_block_info::free() {

}

void stored_block_info::copy(const stored_block_info &item)  {
    type = item.type;
    id = item.id;
    line = item.line;
    reachable = item.reachable;
    endLabel = item.endLabel;
    repeatLoopLabel = item.repeatLoopLabel;
    finallyLabel = item.finallyLabel;
    lockExpression = item.lockExpression;
}

void stored_context_item::copy(const stored_context_item &item)  {

    type = item.type;
    classCxt = item.classCxt;
    functionCxt = item.functionCxt;
    componentCtx = item.componentCtx;
    fieldCxt = item.fieldCxt;
    localFields.addAll(item.localFields);
    localAliases.addAll(item.localAliases);
    labels.addAll(item.labels);
    isStatic = item.isStatic;
    blockInfo.copy_all(item.blockInfo);
}
