//
// Created by BNunnally on 9/1/2021.
//

#ifndef SHARP_SHARP_FUNCTION_H
#define SHARP_SHARP_FUNCTION_H

#include "../../../../stdimports.h"
#include "../../List.h"
#include "../dependency/dependancy.h"
#include "../meta_data.h"
#include "../../../core/access_flag.h"
#include "sharp_type.h"
#include "generic_type_identifier.h"
#include <vector>
#include "../../../core/function_type.h"
#include "../../settings/settings.h"
#include "../compiler/obfuscate_compiler.h"

struct code_info;
struct sharp_class;
struct sharp_field;

void set_full_name(sharp_function*);

struct sharp_function {
    sharp_function()
    :
            name(""),
            fullName(""),
            owner(NULL),
            baseConstructor(NULL),
            implLocation(),
            dependencies(),
            flags(flag_none),
            ast(NULL),
            closure(NULL),
            capturedParameter(NULL),
            scheme(NULL),
            delegate(NULL),
            ci(NULL),
            uid(-1),
            used(false),
            obfuscateModifier(options.obfuscate ? modifier_obfuscate : modifier_none),
            returnProtected(false),
            parameters(),
            returnType(),
            locals(),
            impls(),
            aliases(),
            labels(),
            type(undefined_function),
            directlyCopyParams(false)
    {}

    sharp_function(const sharp_function &sf)
            :
            name(sf.name),
            fullName(sf.fullName),
            owner(sf.owner),
            implLocation(sf.implLocation),
            dependencies(sf.dependencies),
            impls(sf.impls),
            flags(sf.flags),
            uid(sf.uid),
            returnProtected(sf.returnProtected),
            baseConstructor(sf.baseConstructor),
            ast(sf.ast),
            delegate(sf.delegate),
            obfuscateModifier(sf.obfuscateModifier),
            parameters(),
            locals(),
            aliases(),
            labels(),
            used(sf.used),
            returnType(sf.returnType),
            type(sf.type),
            closure(sf.closure),
            capturedParameter(sf.capturedParameter),
            directlyCopyParams(sf.directlyCopyParams),
            scheme(NULL),
            ci(NULL)
    {
        copy_parameters(sf.parameters);
        copy_locals(sf.locals);
        copy_scheme(sf.scheme);
    }

    sharp_function(
            string &name,
            sharp_class *owner,
            impl_location location,
            uInt flags,
            Ast *ast,
            List<sharp_field*> &parameters,
            sharp_type &returnType,
            function_type type,
            bool directlyCopyParams = false)
    :
            name(name),
            fullName(""),
            owner(owner),
            implLocation(location),
            dependencies(),
            parameters(),
            flags(flags),
            ast(ast),
            uid(-1),
            returnType(),
            type(type),
            locals(),
            impls(),
            aliases(),
            labels(),
            used(false),
            returnProtected(false),
            directlyCopyParams(directlyCopyParams),
            scheme(NULL),
            baseConstructor(NULL),
            obfuscateModifier(options.obfuscate ? modifier_obfuscate : modifier_none),
            closure(NULL),
            capturedParameter(NULL),
            delegate(NULL),
            ci(NULL)
    {
        this->returnType.copy(returnType);
        if(!directlyCopyParams)
            copy_parameters(parameters);
        else this->parameters.addAll(parameters);
        set_full_name(this);
    }

    ~sharp_function() {
        free();
    }

    void free();
    void copy_parameters(const List<sharp_field*> &params);
    void copy_scheme(operation_schema *operations);
    void copy_locals(const List<sharp_field*> &params);

    string name;
    string fullName;
    sharp_class *owner;
    impl_location implLocation;
    List<dependency> dependencies;
    List<sharp_field*> parameters;
    List<sharp_field*> locals;
    List<sharp_alias*> aliases;
    List<sharp_label*> labels;
    operation_schema *scheme;
    // Closures (dependency/closure_capture.h):
    //   closure             `__closure`, the local that holds this function's
    //                       closure object; NULL when no lambda captures from it
    //   capturedParameter   `__captured`, the hidden last parameter of a lambda
    //                       that captures: the closure object of the function
    //                       around it; NULL for every other function
    sharp_field* closure;
    sharp_field* capturedParameter;
    sharp_function* delegate;
    List<sharp_function*> impls;
    sharp_type returnType;
    sharp_function* baseConstructor;
    function_type type;
    bool used;
    obfuscation_modifier obfuscateModifier;
    bool returnProtected;

    // Lazy compilation (compiler/functions/lazy_functions.h): the body of a
    // library function is not compiled where it is met, only when something
    // that is used turns out to need it. Until then this says where the
    // compiler was: the syntax tree of the function, the file and module that
    // were current, and the class context it was in.
    // For the init function of a class (the one all `init { }` blocks are
    // compiled into): the step at which the code of the first init block
    // starts. The initial values of the fields are put in front of it, so
    // `width : var = 80; init { seen = width; }` sees 80. -1: no init block.
    Int fieldInitPos = -1;

    // An instance of a generic function (compiler/functions/generic_functions.h):
    // the types its type parameters stand for, { T -> std#int, ... }. Empty
    // for every other function. Pushed while the body is compiled.
    std::vector<generic_type_identifier> genericBindings;

    bool bodyPending = false;
    Ast *pendingAst = NULL;
    sharp_file *pendingFile = NULL;
    sharp_module *pendingModule = NULL;
    sharp_class *pendingClass = NULL;
    bool pendingStatic = false;

    code_info *ci;
    uInt flags;
    uInt uid;
    Ast* ast;
    bool directlyCopyParams; // we need to do this for get() expressions to preserve the resolved type definition found
};

bool is_fully_qualified_function(sharp_function*);
void fully_qualify_function(sharp_function*, sharp_function*);
bool function_parameters_match(List<sharp_field*>&, List<sharp_field*>&, bool, uInt excludedMateches = 0);


bool create_function(
        sharp_class *sc,
        uInt flags,
        function_type type,
        string &name,
        bool checkBaseClass,
        List<sharp_field*> &params,
        sharp_type &returnType,
        Ast *createLocation);

bool create_function(
        sharp_class *sc,
        uInt flags,
        function_type type,
        string &name,
        bool checkBaseClass,
        List<sharp_field*> &params,
        sharp_type &returnType,
        Ast *createLocation,
        sharp_function *&createdFun);

void create_default_constructor(sharp_class*, uInt, Ast*);

string function_to_str(sharp_function*);
string parameters_to_str(List<sharp_field*> &);

#endif //SHARP_SHARP_FUNCTION_H
