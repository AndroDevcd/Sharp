//
// Created by BNunnally on 9/17/2021.
//

#ifndef SHARP_EXPRESSION_H
#define SHARP_EXPRESSION_H

#include "../../types/sharp_type.h"
#include "../../operation/operation.h"

struct sharp_file;

struct expression {
    expression()
    :
        type(),
        scheme()
    {}

    expression(const expression &e)
            :
            type(e.type),
            scheme(e.scheme)
    {}

    expression(sharp_type t)
            :
            type(),
            scheme()
    {
        type.copy(t);
    }

    ~expression() {
        scheme.free();
    }


    sharp_type type;
    operation_schema scheme;
};

void compile_expression(expression &, Ast*, Int endLabel = -1);
void compile_cond_expression(expression &, Ast*);
void compile_expression_for_type(expression &, Ast*);
void extract_value_field_from_expression(expression &e, string className, Ast *ast, bool forceError = false);
void recompile_cond_expression(expression &out, Ast *ast);

void convert_expression_type_to_real_type(
        expression &typeDefinition);

bool pre_initialize_class(sharp_class*);

/**
 * This function can be used to call simple constructors or init() calls
 * @param ast
 * @param constructor
 * @param e
 * @param scheme
 */
void compile_initialization_call(
        Ast *ast,
        sharp_function *constructor,
        expression &e,
        operation_schema *scheme);

bool scheme_has_own_layout(_operation_scheme type);
void wrap_scheme_as_value(operation_schema &scheme);

// converting numbers between integer and decimal where a value changes hands
#include "numeric_conversion.h"
sharp_function* compile_class_function_overload(
        sharp_class *with_class,
        expression &e,
        List<sharp_field*> &params,
        List<operation_schema*> &paramOperations,
        string &op,
        Ast *ast,
        bool allowMissing = false);

/**
 * While a `base->...` expression is compiled: the class `base` stands for.
 * Calls to functions of that class (or of its own base classes) are direct
 * calls, never looked up at run time (see "Direct call or run-time lookup?" in
 * expression.cpp). Set and cleared by compile_base_expression(); NULL otherwise.
 */
void set_base_call_class(sharp_class *baseClass);

void compile_function_call(
        operation_schema *scheme,
        List<sharp_field*> & params,
        List<operation_schema*> &paramOperations,
        sharp_function *callee,
        bool isStaticCall,
        bool isPrimaryClass,
        bool isFunctionPointer);

void compile_initialization_call(
        Ast *ast,
        sharp_class *with_class,
        sharp_function *constructor,
        List<sharp_field*> & params,
        List<operation_schema*> &paramOperations,
        operation_schema *scheme);

#endif //SHARP_EXPRESSION_H
