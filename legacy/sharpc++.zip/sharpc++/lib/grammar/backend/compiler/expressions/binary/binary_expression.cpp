//
// Created by BNunnally on 9/24/2021.
//

#include "../../../types/function_value.h"
#include "binary_expression.h"
#include "../expression.h"
#include "../../../../taskdelegator/task_delegator.h"
#include "../../../types/types.h"
#include "../../../../compiler_info.h"
#include "and_expression.h"
#include "equal_expression.h"
#include "less_expression.h"
#include "shift_expression.h"
#include "add_expression.h"
#include "mult_expression.h"
#include "exponent_expression.h"
#include "../../../../settings/settings.h"

void compile_binary_expression(expression *e, Ast *ast) {
    if(ast->getType() == ast_and_e)
        compile_and_expression(e, ast);
    else if(ast->getType() == ast_equal_e)
        compile_equal_expression(e, ast);
    else if(ast->getType() == ast_less_e)
        compile_less_than_expression(e, ast);
    else if(ast->getType() == ast_shift_e)
        compile_shift_expression(e, ast);
    else if(ast->getType() == ast_add_e)
        compile_add_expression(e, ast);
    else if(ast->getType() == ast_mult_e)
        compile_mult_expression(e, ast);
    else if(ast->getType() == ast_exponent_e)
        compile_exponent_expression(e, ast);
}

void expressions_array_check(sharp_type &type, Token &op, Ast *ast) {
    if(type.isArray) {
        create_new_error(GENERIC, ast,
                                                           "expression of type `" + type_to_str(type) + "` must be of type `class` or numeric to use `" + op.getValue() + "` operator");
    }
}

/**
 * This is a quick function to process the common exceptions for an invalid right expression
 * to reduce code clutter and repetitiveness
 * @param e
 * @param left
 * @param right
 * @param operand
 * @param ast
 */
bool compile_expression_exceptions(
        expression &e,
        Token &operand,
        Ast *ast,
        bool allowObject = false) {
    switch(e.type.type) {
        case type_nil: {
            create_new_error(
                    GENERIC, ast, "cannot use `" + operand.getValue() + "` operator on expression that returns nil");
            return true;
        }

        case type_untyped: {
            create_new_error(
                    INTERNAL_ERROR, ast, "cannot apply `" + operand.getValue() + "` operator to untyped expression.");
            return true;
        }

        case type_undefined:
            return true;

        case type_object: {
            if(allowObject) return false;

            create_new_error(GENERIC, ast,
                                                               "expressions of type object must be casted before using `" + operand.getValue() + "` operator, try `(<your-expression> as Type)" + operand.getValue() + " ...` instead");
            return true;
        }

        default:
            return false;
    }
}

Int get_numeric_expression_value_as_int(expression &e) {
    switch(e.type.type) {
        case type_integer:
            return e.type.integer;

        case type_char:
            return e.type._char;

        case type_bool:
            return e.type._bool;

        case type_decimal:
            return e.type.decimal;

        default:
            return 0;
    }
}

/**
 * The value of a number literal as the VM will hold it: a 64-bit double.
 * Literals are parsed into a long double (80 bits on x86), but the program
 * computes with doubles, so the compiler folds `0.1 + 0.2 == 0.3` with doubles
 * too - otherwise the folded answer differs from what the same expression
 * gives at run time with variables.
 */
double get_numeric_expression_value_as_decimal(expression &e) {
    switch(e.type.type) {
        case type_integer:
            return e.type.integer;

        case type_char:
            return e.type._char;

        case type_bool:
            return e.type._bool;

        case type_decimal:
            return e.type.decimal;

        default:
            return 0;
    }
}

void  compile_binary_string_expression(
        expression *e,
        expression &left,
        expression &right,
        Token &operand,
        Ast *ast) {

    if(compile_expression_exceptions(right, operand, ast->getSubAst(1)))
        return;

    string name = "";
    sharp_type type = get_real_type(left.type);
    type.nullable = true;
    List<sharp_field*> params;
    List<operation_schema*> paramOperations;
    impl_location location(current_file, ast);

    params.add(new sharp_field(
            name, get_primary_class(&currThread->currTask->file->ctx), location,
            type, flag_public, normal_field, ast
    ));
    paramOperations.add(new operation_schema(left.scheme));

    string std = "std";
    sharp_class *string_class = resolve_class(get_module(std), "string", false, false);
    sharp_function *constructor = resolve_function("string", string_class, params, constructor_function, exclude_all, ast, false, false);

    if(constructor != NULL) {
        create_dependency(constructor);
        create_dependency(string_class);

        APPLY_TEMP_SCHEME(0, e->scheme,
            compile_initialization_call(ast, string_class, constructor, params, paramOperations, &scheme_0);
            scheme_0.schemeType = scheme_new_class;
        )

        deleteList(params);
        deleteList(paramOperations);
        type = get_real_type(right.type);
        params.add(new sharp_field(
                name, get_primary_class(&currThread->currTask->file->ctx), location,
                type, flag_public, normal_field, ast
        ));

        paramOperations.add(new operation_schema(right.scheme));
        compile_class_function_overload(string_class, *e, params, paramOperations, operand.getValue(), ast);
    } else {
        create_new_error(
                INTERNAL_ERROR, ast->getSubAst(1), "could not find support function in string class for type `" + type_to_str(left.type) + "`");
    }
}

/**
 * The type of `left <operand> right` for number operands that are not both
 * literals.
 *
 * It used to be _int32 for everything, so `n + 1` with n = 2.5 was treated as a
 * whole number wherever the type matters (in a string: "${n + 1}" printed 3).
 * Now: + - * ** give a `var` when either side can hold a fraction (a var or a
 * fractional literal), `/` always gives a `var` (7 / 2 is 3.5), and everything
 * else (comparisons, logic, bit operations, %) stays _int32.
 */
static data_type arithmetic_result_type(Token &operand, sharp_type &left, sharp_type &right) {
    if(operand == "/")
        return type_var;

    if(operand == "+" || operand == "-" || operand == "*" || operand == "**") {
        sharp_type l = get_real_type(left), r = get_real_type(right);
        if(l.type == type_var || l.type == type_decimal || r.type == type_var || r.type == type_decimal)
            return type_var;
    }

    return type_int32;
}

/**
 * Record on the operation step that was just created which kind of operation
 * it is and what its operands need (see set_numeric_operation, operation.h).
 * This is the place to do it: left.type and right.type are still known here,
 * the generator later only sees register numbers.
 *
 *      /  **                   always calculated as decimals
 *      + - *  == != < > <= >=  decimal when either side is a decimal
 *      % & | ^ << >>           always calculated as integers
 */
static void type_binary_operation(operation_schema *scheme, Token &operand, sharp_type &left, sharp_type &right) {
    bool leftIsDecimal = is_decimal_type(left), rightIsDecimal = is_decimal_type(right);
    bool decimalOperation = is_decimal_operator(operand.getValue(), leftIsDecimal, rightIsDecimal);

    set_numeric_operation(scheme, decimalOperation, leftIsDecimal, rightIsDecimal);

    // 2 ** 3 is calculated with decimals (pow) but its type is a whole number
    if(operand == "**" && arithmetic_result_type(operand, left, right) != type_var)
        scheme->steps.last()->resultConversion = convert_to_integer;
}

void compile_binary_integer_expression(
        expression *e,
        expression &left,
        expression &right,
        Token &operand,
        Ast *ast) {

    expressions_array_check(left.type, operand, ast->getSubAst(0));
    expressions_array_check(right.type, operand, ast->getSubAst(1));

    if(compile_expression_exceptions(right, operand, ast->getSubAst(1)))
        return;

    switch(right.type.type) {
        case type_integer:
        case type_char:
        case type_bool:
        case type_decimal: {
            Int result = 0;
            // 2 + 3, 7 - 2, 4 * 5: two whole-number literals give a whole
            // number. (They were folded as decimals, so `"n" + (2 + 3)` printed
            // "n5.0000000000000000" where `"n" + 5` prints "n5".)
            if((operand == "+" || operand == "-" || operand == "*")
               && left.type.type != type_decimal && right.type.type != type_decimal) {
                Int whole_left = get_numeric_expression_value_as_int(left);
                Int whole_right = get_numeric_expression_value_as_int(right);
                result = operand == "+" ? whole_left + whole_right
                       : operand == "-" ? whole_left - whole_right
                       : whole_left * whole_right;
                create_get_integer_constant_operation(&e->scheme, result);
                e->type.type = type_integer;
                e->type.integer = result;
                break;
            }

            if(operand == "&") {
                create_get_integer_constant_operation(&e->scheme,
                                                      result = (get_numeric_expression_value_as_int(left) & get_numeric_expression_value_as_int(right)));
            } else if(operand == "^") {
                create_get_integer_constant_operation(&e->scheme,
                                                      result = (get_numeric_expression_value_as_int(left) ^ get_numeric_expression_value_as_int(right)));
            } else if(operand == "|") {
                create_get_integer_constant_operation(&e->scheme,
                                                      result = (get_numeric_expression_value_as_int(left) | get_numeric_expression_value_as_int(right)));
            } else if(operand == "&&") {
                create_get_integer_constant_operation(&e->scheme,
                                                      result = (get_numeric_expression_value_as_int(left) && get_numeric_expression_value_as_int(right)));
            } else if(operand == "||") {
                create_get_integer_constant_operation(&e->scheme,
                                                      result = (get_numeric_expression_value_as_int(left) || get_numeric_expression_value_as_int(right)));
            } else if(operand == "==") {
                long double result = 0;
                create_get_decimal_constant_operation(&e->scheme,
                                                      result = (get_numeric_expression_value_as_decimal(left) == get_numeric_expression_value_as_decimal(right)));

                e->type.type = type_decimal;
                e->type.decimal = result;
                break;
            } else if(operand == "!=") {
                long double result = 0;
                create_get_decimal_constant_operation(&e->scheme,
                                                      result = (get_numeric_expression_value_as_decimal(left) != get_numeric_expression_value_as_decimal(right)));

                e->type.type = type_decimal;
                e->type.decimal = result;
                break;
            } else if(operand == "<") {
                long double result = 0;
                create_get_decimal_constant_operation(&e->scheme,
                                                      result = (get_numeric_expression_value_as_decimal(left) < get_numeric_expression_value_as_decimal(right)));

                e->type.type = type_decimal;
                e->type.decimal = result;
                break;
            } else if(operand == ">") {
                long double result = 0;
                create_get_decimal_constant_operation(&e->scheme,
                                                      result = (get_numeric_expression_value_as_decimal(left) > get_numeric_expression_value_as_decimal(right)));

                e->type.type = type_decimal;
                e->type.decimal = result;
                break;
            } else if(operand == "<=") {
                long double result = 0;
                create_get_decimal_constant_operation(&e->scheme,
                                                      result = (get_numeric_expression_value_as_decimal(left) <= get_numeric_expression_value_as_decimal(right)));

                e->type.type = type_decimal;
                e->type.decimal = result;
                break;
            } else if(operand == ">=") {
                long double result = 0;
                create_get_decimal_constant_operation(&e->scheme,
                                                      result = (get_numeric_expression_value_as_decimal(left) >= get_numeric_expression_value_as_decimal(right)));

                e->type.type = type_decimal;
                e->type.decimal = result;
                break;
            } else if(operand == "<<") {
                create_get_integer_constant_operation(&e->scheme,
                                                      result = (get_numeric_expression_value_as_int(left) << get_numeric_expression_value_as_int(right)));
            } else if(operand == ">>") {
                create_get_integer_constant_operation(&e->scheme,
                                                      result = (get_numeric_expression_value_as_int(left) >> get_numeric_expression_value_as_int(right)));
            } else if(operand == "-") {
                long double result = 0;
                create_get_decimal_constant_operation(&e->scheme,
                                                      result = (get_numeric_expression_value_as_decimal(left) - get_numeric_expression_value_as_decimal(right)));

                e->type.type = type_decimal;
                e->type.decimal = result;
                break;
            } else if(operand == "+") {
                long double result = 0;
                create_get_decimal_constant_operation(&e->scheme,
                                                      result = (get_numeric_expression_value_as_decimal(left) + get_numeric_expression_value_as_decimal(right)));

                e->type.type = type_decimal;
                e->type.decimal = result;
                break;
            } else if(operand == "/") {
                // (this used to ADD the two literals, as integers: `20 / 4` gave 24)
                // Division keeps the fraction, exactly like dividing two variables at run time: 7 / 2 is 3.5.
                long double result = 0;
                create_get_decimal_constant_operation(&e->scheme,
                                                      result = (get_numeric_expression_value_as_decimal(left) / get_numeric_expression_value_as_decimal(right)));

                e->type.type = type_decimal;
                e->type.decimal = result;
                break;
            } else if(operand == "*") {
                long double result = 0;
                create_get_decimal_constant_operation(&e->scheme,
                                                      result = (get_numeric_expression_value_as_decimal(left) * get_numeric_expression_value_as_decimal(right)));

                e->type.type = type_decimal;
                e->type.decimal = result;
                break;
            } else if(operand == "%") {
                if(get_numeric_expression_value_as_int(right) == 0) {
                    create_new_error(GENERIC, ast->getSubAst(1), "remainder of a division by zero.");
                    break;
                }

                create_get_integer_constant_operation(&e->scheme,
                                                      result = (get_numeric_expression_value_as_int(left) % get_numeric_expression_value_as_int(right)));
            } else if(operand == "**") {
                long double result = 0;
                create_get_decimal_constant_operation(&e->scheme,
                                                      result = (pow(get_numeric_expression_value_as_decimal(left), get_numeric_expression_value_as_decimal(right))));

                e->type.type = type_decimal;
                e->type.decimal = result;
                break;
            }

            e->type.type = type_integer;
            e->type.integer = result;
            break;
        }

        case type_int8:
        case type_int16:
        case type_int32:
        case type_int64:
        case type_uint8:
        case type_uint16:
        case type_uint32:
        case type_uint64:
        case type_function_ptr:
        case type_var:
        case type_class:
        case type_field: {
            if(right.type.type == type_field || right.type.type == type_class) {
                extract_value_field_from_expression(right, "", ast);
                if(!is_implicit_type_match(left.type, right.type, match_constructor)) {
                    goto error;
                }
            }

            // && and || test each side with a conditional jump, which needs an
            // integer: `0.5 && x` must see 0.5 as true
            if(operand == "||" || operand == "&&") {
                convert_number_to_condition(left);
                convert_number_to_condition(right);
            }

            if(operand == "||") {
                create_or_or_operation(&e->scheme, &left.scheme, &right.scheme);
            } else if(operand == "&&") {
                create_and_and_operation(&e->scheme, &left.scheme, &right.scheme);
            } else {
                ALLOCATE_REGISTER_2X(0, 1, &e->scheme,
                      create_get_value_operation(&e->scheme, &right.scheme, false);
                      create_push_to_stack_operation(&e->scheme);
                      // (a fractional literal used to be loaded as an integer here:
                      //  `0.5 - v` was computed as `0 - v`)
                      if(left.type.type == type_decimal) {
                          create_get_decimal_constant_operation(&e->scheme,
                                                                get_numeric_expression_value_as_decimal(
                                                                        left), false);
                      } else {
                          create_get_integer_constant_operation(&e->scheme,
                                                                get_numeric_expression_value_as_int(
                                                                        left), false);
                      }
                      create_retain_numeric_value_operation(&e->scheme, register_0);
                      create_pop_direct_numeric_value_from_stack_operation(&e->scheme, register_1);
                      create_unused_data_operation(&e->scheme);

                      if (operand == "&") {
                          create_and_operation(&e->scheme, register_0, register_1);
                      } else if (operand == "^") {
                          create_xor_operation(&e->scheme, register_0, register_1);
                      } else if (operand == "|") {
                          create_or_operation(&e->scheme, register_0, register_1);
                      } else if (operand == "==") {
                          create_eq_eq_operation(&e->scheme, register_0, register_1);
                      } else if (operand == "!=") {
                          create_not_eq_operation(&e->scheme, register_0, register_1);
                      } else if (operand == "<") {
                          create_lt_operation(&e->scheme, register_0, register_1);
                      } else if (operand == ">") {
                          create_gt_operation(&e->scheme, register_0, register_1);
                      } else if (operand == "<=") {
                          create_lte_operation(&e->scheme, register_0, register_1);
                      } else if (operand == ">=") {
                          create_gte_operation(&e->scheme, register_0, register_1);
                      } else if (operand == "<<") {
                          create_shl_operation(&e->scheme, register_0, register_1);
                      } else if (operand == ">>") {
                          create_shr_operation(&e->scheme, register_0, register_1);
                      } else if (operand == "+") {
                          create_add_operation(&e->scheme, register_0, register_1);
                      } else if (operand == "-") {
                          create_sub_operation(&e->scheme, register_0, register_1);
                      } else if (operand == "/") {
                          create_div_operation(&e->scheme, register_0, register_1);
                      } else if (operand == "*") {
                          create_mult_operation(&e->scheme, register_0, register_1);
                      } else if (operand == "%") {
                          create_mod_operation(&e->scheme, register_0, register_1);
                      } else if (operand == "**") {
                          create_exponent_operation(&e->scheme, register_0, register_1);
                      }

                      type_binary_operation(&e->scheme, operand, left.type, right.type);
                      e->scheme.schemeType = scheme_binary_math;
                )
            }

            e->type.type = arithmetic_result_type(operand, left.type, right.type);
            break;
        }

        default: {
            error:
            create_new_error(
                    GENERIC, ast->getSubAst(1), "expected numeric type, unqualified use  of operator `" + operand.getValue() + "` with type `" + type_to_str(right.type) + "`");
            break;
        }
    }
}

void compile_binary_numeric_expression(
        expression *e,
        expression &left,
        expression &right,
        Token &operand,
        Ast *ast) {

    expressions_array_check(left.type, operand, ast->getSubAst(0));
    expressions_array_check(right.type, operand, ast->getSubAst(1));

    if(compile_expression_exceptions(right, operand, ast->getSubAst(1)))
        return;

    switch(right.type.type) {
        case type_integer:
        case type_char:
        case type_bool:
        case type_decimal:
        case type_int8:
        case type_int16:
        case type_int32:
        case type_int64:
        case type_uint8:
        case type_uint16:
        case type_uint32:
        case type_uint64:
        case type_function_ptr:
        case type_var:
        case type_class:
        case type_field: {

            if(right.type.type == type_field || right.type.type == type_class) {
                extract_value_field_from_expression(right, "", ast);

                if(!is_implicit_type_match(left.type, right.type, exclude_none)) {
                    goto error;
                }
            }
            // && and || test each side with a conditional jump, which needs an
            // integer: `0.5 && x` must see 0.5 as true
            if(operand == "||" || operand == "&&") {
                convert_number_to_condition(left);
                convert_number_to_condition(right);
            }

            if(operand == "||") {
                create_or_or_operation(&e->scheme, &left.scheme, &right.scheme);
            } else if(operand == "&&") {
                create_and_and_operation(&e->scheme, &left.scheme, &right.scheme);
            } else {
                if (left.scheme.schemeType == scheme_binary_math) {
                    ALLOCATE_REGISTER_1X(0, &e->scheme,
                         create_get_value_operation(&e->scheme, &right.scheme, false);
                         create_push_to_stack_operation(&e->scheme);
                         create_get_value_operation(&e->scheme, &left.scheme, false);
                         create_pop_direct_numeric_value_from_stack_operation(&e->scheme, register_0);
                         create_unused_data_operation(&e->scheme);

                         if (operand == "&") {
                             create_and_operation(&e->scheme, -1, register_0);
                         } else if (operand == "^") {
                             create_xor_operation(&e->scheme, -1, register_0);
                         } else if (operand == "|") {
                             create_or_operation(&e->scheme, -1, register_0);
                         } else if (operand == "==") {
                             create_eq_eq_operation(&e->scheme, -1, register_0);
                         } else if (operand == "!=") {
                             create_not_eq_operation(&e->scheme, -1, register_0);
                         } else if (operand == "<") {
                             create_lt_operation(&e->scheme, -1, register_0);
                         } else if (operand == ">") {
                             create_gt_operation(&e->scheme, -1, register_0);
                         } else if (operand == "<=") {
                             create_lte_operation(&e->scheme, -1, register_0);
                         } else if (operand == ">=") {
                             create_gte_operation(&e->scheme, -1, register_0);
                         } else if (operand == "<<") {
                             create_shl_operation(&e->scheme, -1, register_0);
                         } else if (operand == ">>") {
                             create_shr_operation(&e->scheme, -1, register_0);
                         } else if (operand == "+") {
                             create_add_operation(&e->scheme, -1, register_0);
                         } else if (operand == "-") {
                             create_sub_operation(&e->scheme, -1, register_0);
                         } else if (operand == "/") {
                             create_div_operation(&e->scheme, -1, register_0);
                         } else if (operand == "*") {
                             create_mult_operation(&e->scheme, -1, register_0);
                         } else if (operand == "%") {
                             create_mod_operation(&e->scheme, -1, register_0);
                         } else if (operand == "**") {
                             create_exponent_operation(&e->scheme, -1, register_0);
                         }

                         type_binary_operation(&e->scheme, operand, left.type, right.type);
                         e->scheme.schemeType = scheme_accelerated_binary_math;
                    )
                } else {
                    ALLOCATE_REGISTER_2X(0, 1, &e->scheme,
                         create_get_value_operation(&e->scheme, &right.scheme, false);
                         create_push_to_stack_operation(&e->scheme);
                         create_get_value_operation(&e->scheme, &left.scheme, false);
                         create_retain_numeric_value_operation(&e->scheme, register_0);
                         create_pop_direct_numeric_value_from_stack_operation(&e->scheme, register_1);
                         create_unused_data_operation(&e->scheme);

                         if (operand == "&") {
                             create_and_operation(&e->scheme, register_0, register_1);
                         } else if (operand == "^") {
                             create_xor_operation(&e->scheme, register_0, register_1);
                         } else if (operand == "|") {
                             create_or_operation(&e->scheme, register_0, register_1);
                         } else if (operand == "==") {
                             create_eq_eq_operation(&e->scheme, register_0, register_1);
                         } else if (operand == "!=") {
                             create_not_eq_operation(&e->scheme, register_0, register_1);
                         } else if (operand == "<") {
                             create_lt_operation(&e->scheme, register_0, register_1);
                         } else if (operand == ">") {
                             create_gt_operation(&e->scheme, register_0, register_1);
                         } else if (operand == "<=") {
                             create_lte_operation(&e->scheme, register_0, register_1);
                         } else if (operand == ">=") {
                             create_gte_operation(&e->scheme, register_0, register_1);
                         } else if (operand == "<<") {
                             create_shl_operation(&e->scheme, register_0, register_1);
                         } else if (operand == ">>") {
                             create_shr_operation(&e->scheme, register_0, register_1);
                         } else if (operand == "+") {
                             create_add_operation(&e->scheme, register_0, register_1);
                         } else if (operand == "-") {
                             create_sub_operation(&e->scheme, register_0, register_1);
                         } else if (operand == "/") {
                             create_div_operation(&e->scheme, register_0, register_1);
                         } else if (operand == "*") {
                             create_mult_operation(&e->scheme, register_0, register_1);
                         } else if (operand == "%") {
                             create_mod_operation(&e->scheme, register_0, register_1);
                         } else if (operand == "**") {
                             create_exponent_operation(&e->scheme, register_0, register_1);
                         }

                         type_binary_operation(&e->scheme, operand, left.type, right.type);
                         e->scheme.schemeType = scheme_binary_math;
                    )
                }
            }

            e->type.type = arithmetic_result_type(operand, left.type, right.type);
            break;
        }

        default: {
            error:
            create_new_error(
                    GENERIC, ast->getSubAst(1), "expected numeric type, unqualified use  of operator `" + operand.getValue() + "` with type `" + type_to_str(right.type) + "`");
            break;
        }
    }
}

void compile_binary_object_expression(
        expression *e,
        expression &left,
        expression &right,
        Token &operand,
        Ast *ast) {

    if(compile_expression_exceptions(right, operand, ast->getSubAst(1), true))
        return;

    switch(right.type.type) {
        case type_null: {
            create_get_value_operation(&e->scheme, &left.scheme, false);
            create_check_null_operation(&e->scheme);

            if(operand == "!=") {
                create_not_operation(&e->scheme);
            }

            e->scheme.schemeType = scheme_null_check;

            // 0 or 1, an integer. (It was typed `var`, which did not matter while
            // every number was stored the same way.)
            e->type.type = type_int8;
            break;
        }

        case type_object:
        case type_class:
        case type_function_ptr:     // a function value is an object
        case type_field: {
            if(left.type.isArray != right.type.isArray) {
                create_new_error(
                        GENERIC, ast->getSubAst(1), "mismatched array types, unqualified use  of operator `" + operand.getValue() + "` with type `" + type_to_str(right.type) + "`.");
                break;
            }

            if(right.type == type_field) {
                if(!is_implicit_type_match(left.type, right.type, exclude_none)) {
                    goto error;
                }
            }

            create_get_value_operation(&e->scheme, &right.scheme, false);
            create_push_to_stack_operation(&e->scheme);
            create_get_value_operation(&e->scheme, &left.scheme, false);
            create_push_to_stack_operation(&e->scheme);

            if(operand == "==") {
                create_instance_eq_operation(&e->scheme);
            } else if(operand == "!=") {
                create_instance_not_eq_operation(&e->scheme);
            }

            e->scheme.schemeType = scheme_instance_check;
            e->type.type = type_int8;
            break;
        }

        default: {
            error:
            create_new_error(
                    GENERIC, ast->getSubAst(1), "expected object type, unqualified use  of operator `" + operand.getValue() + "` with type `" + type_to_str(right.type) + "`");
            break;
        }
    }
}

/**
 * `f == g` and `f != g` for two function values.
 *
 * A function value is an object, and using the name of a function makes a new
 * one every time, so "the same object" would be the wrong question:
 *
 *      f := twice;
 *      f == twice          // must be true
 *
 * Two function values are equal when they are the same function with the
 * same captured variables. The library class answers that
 * (platform/kernel/function_value.sharp), the comparison becomes
 *
 *      function_value.same(f, g)       /   function_value.different(f, g)
 *
 *      C++ comparison: comparing two function pointers compares the
 *      addresses; this is that, plus "and the same captures".
 *
 * false: the class is not there, nothing was added (the caller reports it).
 */
static bool compile_function_value_comparison(
        expression *e,
        expression &left,
        expression &right,
        Token &operand,
        Ast *ast) {
    sharp_class *valueClass = function_value_class();
    if(valueClass == NULL) return false;

    List<sharp_field*> params;
    List<operation_schema*> operations;
    string name;
    impl_location location(current_file, ast);
    sharp_type anyObject(type_object);
    anyObject.nullable = true;

    for(Int i = 0; i < 2; i++) {
        params.add(new sharp_field(name, get_primary_class(&current_file->ctx),
                                   location, anyObject, flag_public, normal_field, ast));
        operations.add(new operation_schema());
        create_get_value_operation(operations.last(), i == 0 ? &left.scheme : &right.scheme, false);
    }

    sharp_function *compare = resolve_function(
            operand == "==" ? "same" : "different", valueClass,
            params, normal_function, exclude_all,
            ast, false, false
    );

    bool found = compare != NULL;
    if(found) {
        compile_function_call(&e->scheme, params, operations, compare, true, false, false);
        e->type.copy(compare->returnType);
    }

    deleteList(params);
    deleteList(operations);
    return found;
}

void compile_binary_expression(
        expression *e,
        Ast *ast,
        expression &left,
        expression &right,
        Token &operand) {

    if(compile_expression_exceptions(left, operand, ast->getSubAst(0), true))
        return;

    switch(left.type.type) {

        case type_integer:
        case type_char:
        case type_bool:
        case type_decimal: {
            compile_binary_integer_expression(e, left, right, operand, ast);
            break;
        }

        case type_string: {
            if(operand == "+" || operand == "=="
                || operand == "!=" ) {
                compile_binary_string_expression(e, left, right, operand, ast);
            } else
                goto error;
            break;
        }

        case type_int8:
        case type_int16:
        case type_int32:
        case type_int64:
        case type_uint8:
        case type_uint16:
        case type_uint32:
        case type_uint64:
        case type_function_ptr:
        case type_var:
        case type_field:  {
            // A function value is an object: `callback == null`, `a == b` ask
            // "is there one" / "is it the same one". (It was a number, and
            // was compared like one: `main != 0`.)
            if(left.type.type == type_function_ptr
               || (left.type == type_field && left.type.field->type.type == type_function_ptr)) {
                // two function values: the same function with the same
                // captures? (anything else, `== null` first of all: _object)
                bool rightIsFunction = right.type.type == type_function_ptr
                        || right.type.type == type_lambda_function
                        || (right.type == type_field && right.type.field->type.type == type_function_ptr);

                if(rightIsFunction && (operand == "==" || operand == "!=")
                   && compile_function_value_comparison(e, left, right, operand, ast))
                    break;
                goto _object;
            }

            if(left.type == type_field) {
                if(left.type.field->type.type != type_class && left.type.field->type.type != type_object && !(left.type.field->type.type >= type_int8 && left.type.field->type.type <= type_var)) {
                    goto error;
                } else if(left.type.field->type.type == type_class) {
                    goto _class;
                } else if(left.type.field->type.type == type_object ||
                        (left.type.field->type.type >= type_int8 && left.type.field->type.type <= type_var && left.type.field->type.isArray)) {
                    goto _object;
                }
            } else if(left.type.type >= type_int8 && left.type.type <= type_var && left.type.isArray) {
                goto _object;
            }

            compile_binary_numeric_expression(e, left, right, operand, ast);
            break;
        }
        case type_object: {
            _object:
            if(operand == "==" || operand == "!=") {
                compile_binary_object_expression(e, left, right, operand, ast);
            } else
                goto error;
            break;
        }

        case type_class: {
            _class:
            // `x == null` / `x != null` asks "is there an object?" and nothing
            // else. It never calls the class's own operator==: that function
            // compares CONTENTS (string.operator== made `"" == null` true) and
            // cannot even be called when x is null.
            if(right.type.type == type_null && (operand == "==" || operand == "!=")) {
                compile_binary_object_expression(e, left, right, operand, ast);
                break;
            }

            List<sharp_field *> params;
            List<operation_schema *> operations;
            operations.add(new operation_schema());
            create_get_value_operation(operations.last(), &right.scheme, false);
            convert_expression_type_to_real_type(right);

            string name;
            sharp_type type;
            type.copy(right.type);
            impl_location location(current_file, ast);
            params.add(new sharp_field(name, get_primary_class(&current_file->ctx),
                                       location, type, flag_public, normal_field, ast));

            expression leftOld(left);
            // `new vec(1) + new vec(2)`: the operator function is called ON the
            // left value, by appending the call to the left side's steps. A left
            // side with a layout of its own (a `new`, arithmetic, ...) is first
            // made a single value step - otherwise the generator stopped with
            // "attempting to consume empty machine data".
            if(scheme_has_own_layout(left.scheme.schemeType))
                wrap_scheme_as_value(left.scheme);
            if(compile_class_function_overload(
                    get_class_type(left.type), left, params, operations, operand.getValue(), ast, true)) {
                expressions_array_check(leftOld.type, operand, ast->getSubAst(0));
                e->type.copy(left.type);
                e->scheme.copy(left.scheme);
            } else {
                // no operator function: back to the left side as it was (it
                // may have been wrapped above; the object comparison below
                // needs the original steps)
                left.scheme.free();   // (copy() appends)
                left.scheme.copy(leftOld.scheme);
                compile_binary_object_expression(e, left, right, operand, ast);
            }

            break;
        }

        default: {
            error:
            create_new_error(
                    GENERIC, ast->getSubAst(0), "unqualified use  of operator `"
                    + operand.getValue() + "` with type `" + type_to_str(left.type) + "` and `" + type_to_str(right.type) + "`");
            break;
        }
    }
}
