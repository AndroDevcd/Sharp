//
// Created by bknun on 1/18/2018.
//

#ifndef SHARP_LIST2_H
#define SHARP_LIST2_H

#include "../../stdimports.h"
#include <algorithm>

/**
 * The compiler's growable array.
 *
 * STORAGE: `_Data` has room for `cap` elements, of which the first `len` are in
 * use. When the room runs out it is doubled, so adding n elements one by one
 * copies each element a constant number of times on average.
 *
 * (Until 2026 every add() allocated a new array exactly one element larger and
 * copied everything over: adding n elements copied about n*n/2 of them. The
 * tokenizer adds one token at a time, and that alone was three quarters of the
 * compiler's run time - see `sharpc -timings`.)
 *
 * Slots between len and cap hold default-constructed values: a slot is reset
 * when its element is removed, so nothing stale is kept alive there.
 */
template <class T>
class List {
public:
    List(){
        init();
    }

    List(const List<T> &lst){
        init();
        addAll(lst);
    }

    void init(){
        _Data=NULL;
        len=0;
        cap=0;
    }

    void push_back(T& data) {
        __expand();
        _Data[len-1]=data;
    }

    void add(T data) {
        __expand();
        _Data[len-1]=data;
    }

    T& __new() {
        __expand();
        _Data[len-1] = T();     // a fresh element, whatever the slot held before
        return _Data[len-1];
    }

    T& operator[](uInt pos) {
        return get(pos);
    }

    void insert(uint32_t pos, T& data) {
        if(pos>len || pos < 0) {
            stringstream ss;
            ss << "index out of bounds list::insert() _X: " << pos
               << " length: " << len << endl;
            throw std::runtime_error(ss.str());
        }

        // (a copy first: `data` may refer to an element of this list, which moves below)
        T value = data;
        __expand();
        for(uint32_t i = len - 1; i > pos; i--)
            _Data[i] = _Data[i - 1];
        _Data[pos] = value;

    }

    /*
     * Programmer must be responsible
     * for freeing that data himself
     */
    void removeAt(uint32_t _X) {
        if(_X>=len || len==0){
            stringstream ss;
            ss << "index out of bounds list::removeAt() _X: " << _X
               << " length: " << len << endl;
            throw std::runtime_error(ss.str());
        }

        for(uint32_t i = _X; i + 1 < len; i++)
            _Data[i] = _Data[i + 1];
        __shrink();


    }

    /*
     * Programmer must be responsible
     * for freeing that data himself
     */
    void remove(T& _X) {
        for(uint32_t i = 0; i < len; i++) {
            if(_X == _Data[i]) {
                removeAt(i);
                return;
            }
        }
    }

    T at(uint32_t _X) {
        if(_X>=len){
            stringstream ss;
            ss << "index out of bounds list::get() _X: " << _X
               << " length: " << len << endl;
            throw std::runtime_error(ss.str());
        }
        return _Data[_X];
    }

    T & get(uint32_t _X) const {
        if(_X>=len || _X < 0){
            stringstream ss;
            ss << "index out of bounds list::get() _X: " << _X
               << " length: " << len << endl;
            throw std::runtime_error(ss.str());
        }
        return _Data[_X];
    }

    T& last() {
        if(len == 0){
            stringstream ss;
            ss << "illegal state list::last() length: 0" << endl;
            throw std::runtime_error(ss.str());
        }
        return _Data[len-1];
    }

    T& last(uint32_t _X) {
        if(len == 0){
            stringstream ss;
            ss << "illegal state list::last() length: 0" << endl;
            throw std::runtime_error(ss.str());
        }
        return _Data[len - (1 + _X)];
    }

    T& first() {
        if(len == 0){
            stringstream ss;
            ss << "illegal state list::last() length: 0" << endl;
            throw std::runtime_error(ss.str());
        }
        return _Data[0];
    }

    void free() {
        if(_Data != NULL)
            delete[] (_Data);
        _Data = NULL;
        len=0;
        cap=0;
    }

    uint32_t size() const { return len; }

    bool singular() { return len == 1; }

    void pop_back() {
        __shrink();
    }

    void drop(uint32_t _X) {
        for(Int i = 0; i < _X; i++) {
            pop_back();
        }
    }

    bool addif(T _V) {
        for(uint32_t i = 0; i < len; i++) {
            if(_V == _Data[i])
                return false;
        }

        push_back(_V);
        return true;
    }


    int32_t addIfIndex(T _V) {
        for(uint32_t i = 0; i < len; i++) {
            if(_V == _Data[i])
                return i;
        }

        push_back(_V);
        return len - 1;
    }

    bool sameElements(List<T> &list) {
        for(uint32_t i = 0; i < len; i++) {
            if(list._Data[i] != _Data[i])
                return false;
        }

        return true;
    }

    void removefirst(T _V) {
        uint32_t iter = -1;
        for(uint32_t i = 0; i < len; i++) {
            if(_V == _Data[i]){
                iter = i;
                break;
            }
        }

        if(iter != -1) {
            removeAt(iter);
        }
    }

    /*
     * Programmer must be responsible
     * for freeing that data himself
     */
    void replace(uint32_t _X, T repl) {
        if(_X>=len || _X < 0){
            stringstream ss;
            ss << "index out of bounds list::replaceat() _X: " << _X
               << " length: " << len << endl;
            throw std::runtime_error(ss.str());
        }
        _Data[_X] = repl;
    }

    void addAll(const List<T>& list) {
        free();
        for(uint32_t i = 0; i < list.size(); i++) {
            push_back(list.get(i));
        }
    }

    void addAllUnique(List<T>& list) {
        free();
        for(uint32_t i = 0; i < list.size(); i++) {
            addif(list.get(i));
        }
    }

    void appendAll(List<T>& list) {
        for(uint32_t i = 0; i < list.size(); i++) {
            push_back(list.get(i));
        }
    }

    void appendAllUnique(List<T>& list) {
        for(uint32_t i = 0; i < list.size(); i++) {
            addif(list.get(i));
        }
    }

    void addAll(list<T> &list) {
        free();
        for(T& t : list) {
            push_back(t);
        }
    }

    bool find(T data) {
        for(uint32_t i = 0; i < len; i++) {
            if(data == _Data[i]){
                return true;
            }
        }
        return false;
    }

    long long count(T data) {
        long long num=0;
        for(uint32_t i = 0; i < len; i++) {
            if(data == _Data[i]){
                num++;
            }
        }
        return num;
    }

    int32_t indexof(T data) {
        for(uint32_t i = 0; i < len; i++) {
            if(data == _Data[i]){
                return i;
            }
        }
        return -1;
    }

    int32_t indexof(bool (*isElement)(T* e, void *e2), void *e2) {
        for(uint32_t i = 0; i < len; i++) {
            if(isElement(&_Data[i], e2)){
                return i;
            }
        }
        return -1;
    }

    bool find(bool (*isElement)(T* e, void *e2), void *e2) {
        for(uint32_t i = 0; i < len; i++) {
            if(isElement(&_Data[i], e2)){
                return true;
            }
        }
        return false;
    }

    void linearSort(bool (*swap)(T e1, T e2)) {
        for(uint32_t i = 0; i < len; i++) {

            for (uint32_t j = 0; j < len; j++) {
                if((j + 1) < len) {
                    if (swap(_Data[j], _Data[j+1])) {
                        T tmp = _Data[j];
                        _Data[j] = _Data[j+1];
                        _Data[j+1] = tmp;
                    }
                }
            }
        }

    }

    bool empty() { return len==0; }

private:
    CXX11_INLINE
    void __expand() {
        // make room for one more element (the caller fills _Data[len-1])
        if(len == cap) {
            uint32_t newCap = cap == 0 ? 4 : cap * 2;
            T* newbuf = new T[newCap];
            for(uint32_t i = 0; i < len; i++) {
                newbuf[i] = _Data[i];
            }
            delete[] _Data;
            _Data = newbuf;
            cap = newCap;
        }
        len++;
    }

    CXX11_INLINE
    void __shrink(){
        // drop the last element
        if(len == 0) return;
        if(len == 1) {
            free();
            return;
        }

        _Data[len-1] = T();     // let go of whatever it held
        len--;
    }

    uint32_t len;   // elements in use
    uint32_t cap;   // elements _Data has room for
    T* _Data;
};

#endif //SHARP_LIST2_H
